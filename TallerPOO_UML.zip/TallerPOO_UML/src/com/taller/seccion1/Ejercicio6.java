package com.taller.seccion1;
import java.util.Scanner;

public class Ejercicio6 {

	
	
	    public static void main(String[] args) {
	        // Crear un objeto Scanner para leer desde la entrada estándar (teclado)
	        Scanner scanner = new Scanner(System.in);

	        // Leer un número entero
	        System.out.print("Introduce un número entero: ");
	        int numeroEntero = scanner.nextInt();

	        // Leer un número decimal
	        System.out.print("Introduce un número decimal: ");
	        double numeroDecimal = scanner.nextDouble();

	        // Mostrar los valores leídos
	        System.out.println("Número entero ingresado: " + numeroEntero);
	        System.out.println("Número decimal ingresado: " + numeroDecimal);

	        // Cerrar el objeto Scanner para liberar recursos
	        scanner.close();
	    }
	}

