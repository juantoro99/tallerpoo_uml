package com.taller.seccion1;


public class Ejercicio11 {

	
	
	
	    public static void main(String[] args) {
	        // Generar un número aleatorio entre 1 y 10
	        int numeroAleatorio = (int) (Math.random() * 10) + 1;
	        System.out.println("Número aleatorio entre 1 y 10: " + numeroAleatorio);
	    }
	}
