package com.taller.seccion1;

public class Ejercicio4 {


	    public static void main(String[] args) {
	        // Declaración e inicialización de variables
	        int edad = 25;
	        int temperatura = 30;
	        boolean tieneLicencia = true;
	        boolean esEstudiante = false;

	        // Operadores relacionales
	        System.out.println("Edad >= 18: " + (edad >= 18)); // true
	        System.out.println("Temperatura < 25: " + (temperatura < 25)); // false
	        System.out.println("Edad == 25: " + (edad == 25)); // true
	        System.out.println("Edad != 30: " + (edad != 30)); // true

	        // Operadores lógicos
	        System.out.println("tieneLicencia && esEstudiante: " + (tieneLicencia && esEstudiante)); // false
	        System.out.println("tieneLicencia || esEstudiante: " + (tieneLicencia || esEstudiante)); // true
	        System.out.println("!(edad < 18): " + !(edad < 18)); // true

	        // Combinación de operadores
	        boolean puedeConducir = (edad >= 18 && tieneLicencia) || esEstudiante;
	        System.out.println("¿Puede conducir? " + puedeConducir); // true
	    }
	}
