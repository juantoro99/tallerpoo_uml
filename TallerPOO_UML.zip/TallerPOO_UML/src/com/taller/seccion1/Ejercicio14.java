package com.taller.seccion1;

public class Ejercicio14 {

	
	    public static void main(String[] args) {
	        // Declarar cadenas de ejemplo
	        String cadena1 = "";
	        String cadena2 = "Hola";

	        // Comprobar si las cadenas están vacías
	        System.out.println("¿Está 'cadena1' vacía? " + cadena1.isEmpty()); // true
	        System.out.println("¿Está 'cadena2' vacía? " + cadena2.isEmpty()); // false
	    }
	}
