package com.taller.seccion2;
import java.util.Scanner;
public class Ejercicio2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		 // solicitar al usuario que ingrese su edad
		System.out.print ("ingrse su edad :" );
		int edad = sc.nextInt();
		
		// calificar las edades con if-else - else if 
		
		if (edad>0 && edad<=12) {
		System.out.println("eres un niño ");
		
		} else if (edad>12 && edad<=16) {
			System.out.println("eres un adolecente");
			
		} else if (edad>18 && edad<=64) {
			System.out.println("eres adulto");
			
		} else if (edad>64 && edad <=90 ) {
			System.out.println("eres anciano");
			
			
		}
		
		
		
		
	}

}
