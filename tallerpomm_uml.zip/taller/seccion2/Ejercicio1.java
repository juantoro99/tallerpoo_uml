package com.taller.seccion2;

public class Ejercicio1 {

	public static void main(String[] args) {
	int edad = 19 ;
	 
	if (edad>=18) {
		System.out.println("eres mayor de edad");
		
	} else {
		System.out.println("eres menor de edad");
	}
			

	}

}
