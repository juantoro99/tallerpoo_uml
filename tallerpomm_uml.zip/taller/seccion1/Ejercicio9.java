package com.taller.seccion1;


	
	
import java.util.Scanner;

public class Ejercicio9 {

    // Declaración de constantes
    static final double PI = 3.14159;
    static final String MENSAJE_BIENVENIDA = "¡Bienvenido al programa!";
    static final int MAX_INT = 100;

    public static void main(String[] args) {
        // Mostrar mensaje de bienvenida
        System.out.println(MENSAJE_BIENVENIDA);

        // Crear un objeto Scanner para leer desde la entrada estándar (teclado)
        Scanner scanner = new Scanner(System.in);

        // Leer un número entero desde la consola
        System.out.print("Introduce un número entero: ");
        String inputInt = scanner.nextLine();
        try {
            int numeroInt = Integer.parseInt(inputInt);
            System.out.println("Número entero: " + numeroInt);
        } catch (NumberFormatException e) {
            System.out.println("Error: '" + inputInt + "' no es un número entero válido.");
        }

        // Leer un número decimal desde la consola
        System.out.print("Introduce un número decimal: ");
        String inputDouble = scanner.nextLine();
        try {
            double numeroDouble = Double.parseDouble(inputDouble);
            System.out.println("Número decimal: " + numeroDouble);
        } catch (NumberFormatException e) {
            System.out.println("Error: '" + inputDouble + "' no es un número decimal válido.");
        }

        // Cerrar el objeto Scanner para liberar recursos
        scanner.close();
    }
}
