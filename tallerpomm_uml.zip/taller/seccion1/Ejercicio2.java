package com.taller.seccion1;

public class Ejercicio2 {

	public static void main(String[] args) {
		
		int edad = 30;
        double altura = 1.75;
        char inicial = 'J';
        String nombre = "Juan";
        boolean esEstudiante = true;
		
		
		System.out.println("Edad: " + edad);
        System.out.println("Altura: " + altura);
        System.out.println("Inicial: " + inicial);
        System.out.println("Nombre: " + nombre);
        System.out.println("Es estudiante " + esEstudiante);
	}

}
