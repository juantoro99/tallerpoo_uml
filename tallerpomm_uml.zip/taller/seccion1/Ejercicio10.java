package com.taller.seccion1;

public class Ejercicio10 {

	
	
	    public static void main(String[] args) {
	        // Declarar dos números
	        double base = 5;
	        double exponente = 3;
	        double numeroParaRaiz = 16;

	        // Calcular potencia: base^exponente
	        double potencia = Math.pow(base, exponente);
	        System.out.println(base + " elevado a " + exponente + " = " + potencia);

	        // Calcular raíz cuadrada
	        double raizCuadrada = Math.sqrt(numeroParaRaiz);
	        System.out.println("Raíz cuadrada de " + numeroParaRaiz + " = " + raizCuadrada);
	    }
	}
