package com.taller.seccion1;

public class Ejercicio7 {

	
	    public static void main(String[] args) {
	        // Cadena de texto que representa un número
	        String numeroStr = "123";

	        // Convertir de String a int
	        int numeroInt = Integer.parseInt(numeroStr);
	        System.out.println("Cadena a int: " + numeroInt);

	        // Convertir de String a double
	        double numeroDouble = Double.parseDouble(numeroStr);
	        System.out.println("Cadena a double: " + numeroDouble);
	    }
	}
