package com.taller.seccion1;

public class Ejercicio3 {

	public static void main(String[] args) {
		 int a = 15;
	        int b = 4;

	        // Suma
	        int suma = a + b;
	        System.out.println("Suma: " + suma); 

	        // Resta
	        int resta = a - b;
	        System.out.println("Resta: " + resta); 

	        // Multiplicación
	        int multiplicacion = a * b;
	        System.out.println("Multiplicación: " + multiplicacion);

	        // División
	        int division = a / b;
	        System.out.println("División (entera): " + division);

	        // Módulo
	        int modulo = a % b;
	        System.out.println("Módulo: " + modulo);
	}

}
