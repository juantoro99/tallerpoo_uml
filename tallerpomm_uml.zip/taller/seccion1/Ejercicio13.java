package com.taller.seccion1;
import java.util.Scanner;

public class Ejercicio13 {

	

 
    public static void main(String[] args) {
        // Crear un objeto Scanner para leer desde la consola
        Scanner scanner = new Scanner(System.in);

        // Solicitar al usuario que ingrese un carácter
        System.out.print("Introduce un carácter: ");
        char caracter = scanner.next().charAt(0);

        // Obtener el valor ASCII del carácter
        int valorASCII = (int) caracter;

        // Mostrar el valor ASCII
        System.out.println("El valor ASCII de '" + caracter + "' es: " + valorASCII);

        // Cerrar el scanner
        scanner.close();
    }
}
