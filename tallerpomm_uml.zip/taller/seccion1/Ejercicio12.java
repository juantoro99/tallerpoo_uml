package com.taller.seccion1;


public class Ejercicio12 {

	
	
	    public static void main(String[] args) {
	        // Declaración de variables
	        int edad = 25;
	        double altura = 1.75;
	        String nombre = "Juan";

	        // Formateo de salida
	        System.out.printf("Nombre: %-10s | Edad: %3d | Altura: %.2f metros%n", nombre, edad, altura);
	    }
	}
