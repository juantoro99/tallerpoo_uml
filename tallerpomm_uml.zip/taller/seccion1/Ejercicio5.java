package com.taller.seccion1;

public class Ejercicio5 {


	    public static void main(String[] args) {
	        // Declaración e inicialización de variables
	        int a = 10; // Variable entera 'a' con valor 10
	        int b = 3;  // Variable entera 'b' con valor 3
	        double x = 5.5; // Variable doble 'x' con valor 5.5
	        double y = 2.2; // Variable doble 'y' con valor 2.2
	        boolean esMayor = false; // Variable booleana 'esMayor' inicializada en false

	        // Operaciones aritméticas
	        int suma = a + b; // Suma de 'a' y 'b'
	        int resta = a - b; // Resta de 'a' y 'b'
	        int multiplicacion = a * b; // Multiplicación de 'a' y 'b'
	        double division = x / y; // División de 'x' entre 'y'
	        int modulo = a % b; // Módulo de 'a' entre 'b'

	        // Mostrar resultados de operaciones aritméticas
	        System.out.println("Suma: " + suma); // Imprime la suma
	        System.out.println("Resta: " + resta); // Imprime la resta
	        System.out.println("Multiplicación: " + multiplicacion); // Imprime la multiplicación
	        System.out.println("División: " + division); // Imprime la división
	        System.out.println("Módulo: " + modulo); // Imprime el módulo

	        // Operaciones relacionales
	        esMayor = a > b; // Verifica si 'a' es mayor que 'b'
	        System.out.println("¿a es mayor que b? " + esMayor); // Imprime el resultado de la comparación

	        // Operaciones lógicas
	        boolean resultadoLogico = (a > b) && (x > y); // Verifica si ambas condiciones son verdaderas
	        System.out.println("¿a > b y x > y? " + resultadoLogico); // Imprime el resultado lógico

	        resultadoLogico = (a < b) || (x > y); // Verifica si al menos una condición es verdadera
	        System.out.println("¿a < b o x > y? " + resultadoLogico); // Imprime el resultado lógico

	        resultadoLogico = !(a == b); // Verifica si 'a' no es igual a 'b'
	        System.out.println("¿a no es igual a b? " + resultadoLogico); // Imprime el resultado lógico
	    }
	}
